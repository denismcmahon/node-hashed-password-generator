# node-hashed-password-generator
Node application to hash a password
